var TAG = 'LIVE VIEW';

navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia;
var rec;
/**
 * Init microphone success
 *
 * @param s
 * @method onSuccess
 */
var onSuccess = function (s) {
    localStream = s;
    window.AudioContext = window.AudioContext || window.webkitAudioContext || window.mozAudioContext;
    var context = new AudioContext();
    var mediaStreamSource = context.createMediaStreamSource(s);
    rec = new Recorder(mediaStreamSource);
    if (rec) {
        recordingReady = true;
        console.log(TAG, 'onSuccess: The micphone is ready!');
        if (wsReady) {//all things is ready
            showOrHiddenMicPlay();
        }
    }
};
/**
 * Init microphone fail
 *
 * @param error
 * @method onFail
 */
var onFail = function (error) {
    console.log(TAG, 'onFail: Rejected!');
    showOrHiddenMicPlay();
    switch (error.code || error.name) {
        case 'PERMISSION_DENIED':
        case 'PermissionDeniedError':
            alert('You refuse to provide information.So can not use the remote audio function!');
            console.log(TAG, 'onFail: User refuse to provide information.');
            break;
        case 'NOT_SUPPORTED_ERROR':
        case 'NotSupportedError':
            alert('Browser does not support hardware devices.So can not use the remote audio function!');
            console.log(TAG, 'onFail: Browser does not support hardware devices.');
            break;
        case 'MANDATORY_UNSATISFIED_ERROR':
        case 'MandatoryUnsatisfiedError':
            alert('Could not find the specified hardware device.So can not use the remote audio function!');
            console.log(TAG, 'onFail: Could not find the specified hardware device.');
            break;
        default:
            alert('Could not open the microphone.So can not use the remote audio function! Exception information:' + (error.code || error.name));
            console.log(TAG, 'onFail: Could not open the microphone. Exception information:' + (error.code || error.name), 'default');
            break;
    }
};
/**
 * Init microphone
 *
 * @method initMicrophone
 */
function initMicrophone() {
    if (navigator.getUserMedia) {
        navigator.getUserMedia({audio: true}, onSuccess, onFail);
    } else {
        console.log(TAG, 'initMicrophone: navigator.getUserMedia not present');
    }
}


var initFlag = false;

$('#microphone').click(function () {
    if (false == initFlag) {
        initFlag = true;
        initRemoteMic(initMicrophone);
    }
});
$('#shutdownMicrophone').click(function () {
    if (ws) {
        ws.close();
        wsReady = false;
    }
    if (rec) {
        rec.stop();
    }
    initFlag = false;
});


// var webSocketUrl = 'ws://' + window.location.host + '/IPCAdmin/remoteAudio';
var webSocketUrl = 'ws://192.168.1.111:8080/IPCAdmin/remoteAudio';
var ws = null;
var wsReady = false;//the websocket status.
/**
 * Init remote microphone
 *
 * @param {function} cb callback function
 * @method initRemoteMic
 */
function initRemoteMic(cb) {
    ws = new WebSocket(webSocketUrl);
    ws.onopen = function () {
        console.log(TAG, 'initRemoteMic: Openened connection to websocket');
        wsReady = true;
        if (cb) {
            cb();
        }
        initFlag = false;
    };
    ws.onclose = function () {
        console.log(TAG, 'onSuccess: Close connection to websocket');
        wsReady = false;
        showOrHiddenMicPlay();
        initFlag = false;
    };
    ws.onmessage = function (e) {
        console.log(TAG, 'initRemoteMic websocket onmessage:' + e.data);
    };
}

$('#mic_play').click(function () {

    if ($(this).text() == '捕获音频') {
        $(this).text('捕获中...');
        if (null != rec && null != ws) {
            ws.send('start');
            console.log('start');
            rec.record(function (blob) {
                console.log('record');
                ws.send(blob);
            });
        }
    } else {
        stopMicPlay();
        $(this).text('捕获音频');
    }
});

// $('#mic_play').mousedown(function () {
//     if (null != rec && null != ws) {
//         ws.send('start');
//         console.log('start');
//         rec.record(function (blob) {
//
//             console.log('record');
//             ws.send(blob);
//         });
//     }
// });

/**
 * Stop microphone.
 *
 * @method stopMicPlay
 */
function stopMicPlay() {
    if (null != rec && null != ws) {
        rec.stop();
        ws.send('stop');
    }
}

// $('#mic_play').mouseup(stopMicPlay);
// $('#mic_play').mouseout(stopMicPlay);

/**
 * Show or hidden microphone play icon.
 *
 * @method showOrHiddenMicPlay
 */
function showOrHiddenMicPlay() {
    // if (recordingReady && wsReady) {
    //     $('#microphone').addClass(OPEN_CLS);
    //     $('#microphone').attr('data-page', OPEN_STATUS);
    //     $('#mic_play').removeClass('hidden');
    // } else {
    //     $('#mic_play').addClass('hidden');
    //     $('#microphone').removeClass(OPEN_CLS);
    //     $('#microphone').attr('data-page', CLOSE_STATUS);
    //     if (ws) {
    //         ws.close();
    //     }
    //     if (rec) {
    //         rec.stop();
    //     }
    // }
}
