/* Copyright (c) 2015 Qualcomm Technologies, Inc.
 * All Rights Reserved.
 * Confidential and Proprietary - Qualcomm Technologies, Inc.
 */

var buffer,
    bytes,
    dataview,
    sampleRate,
    audioBlob,
    first=true;

this.onmessage = function (e) {
    switch (e.data.command) {
        case 'init':
            init(e.data.config);
            break;
        case 'record':
            record(e.data.buffer);
            break;
        case 'clear':
            clear();
            break;
    }
};

function init(config) {
    sampleRate = config.sampleRate;
    first = true;
}

function record(inputBuffer) {
    buffer =new Float32Array(inputBuffer);
    bytes = compress(buffer);
    dataview = first?firstEncodeWAV(bytes):encodeWAV(bytes);
    audioBlob = new Blob([dataview], { type: 'audio/wav' });
    this.postMessage(audioBlob);
    first = false;
}

function compress(buffer) { //zip data
    var compression = parseInt(sampleRate / 8000);
    var length = parseInt(buffer.length / compression)+1;
    var result = new Float32Array(length);
    var index = 0, j = 0;
    while (index < length) {
        result[index] = buffer[j];
        j += compression;
        index++;
    }
    return result;
}

function floatTo8BitPCM(output, offset, input) {
    for (var i = 0; i < input.length; i++, offset++) {
        var s = Math.max(-1, Math.min(1, input[i]));
        var val = s < 0 ? s * 0x8000 : s * 0x7FFF;
        val = parseInt(255 / (65535 / (val + 32768)));
        output.setInt8(offset, val, true);
    }
}

function writeString(view, offset, string) {
    for (var i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
    }
}

function encodeWAV(samples) {
    var buffer = new ArrayBuffer(samples.length );
    var view = new DataView(buffer);
    floatTo8BitPCM(view, 0, samples);
    return view;
}
function firstEncodeWAV(samples){
     var dataLength = samples.length;
     var buffer = new ArrayBuffer(44 + dataLength);
     var view = new DataView(buffer);
     var channelCount = 1;//only one channel
     var sampleBits = 8;
     // RIFF identifier
     writeString(view, 0, 'RIFF');
      //file length
     view.setUint32(4, 36 + dataLength, true);
    //  RIFF type
     writeString(view, 8, 'WAVE');
      //format chunk identifier
     writeString(view, 12, 'fmt ');
     // format chunk length
     view.setUint32(16, 16, true);
     // sample format (raw)
     view.setUint16(20, 1, true);
     // channel count
     view.setUint16(22, channelCount, true);
     // sample rate
     view.setUint32(24, sampleRate/6, true);
     // byte rate (sample rate * block align)
     view.setUint32(28,channelCount*sampleRate*(sampleBits/8), true);
      //block align (channel count * bytes per sample)
     view.setUint16(32, channelCount*(sampleBits/8), true);
      //bits per sample
     view.setUint16(34, sampleBits, true);
     // data chunk identifier
     writeString(view, 36, 'data');
     // data chunk length
     view.setUint32(40, dataLength, true);
     floatTo8BitPCM(view, 44, samples);
     return view;
}