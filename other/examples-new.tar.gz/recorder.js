/* Copyright (c) 2015 Qualcomm Technologies, Inc.
 * All Rights Reserved.
 * Confidential and Proprietary - Qualcomm Technologies, Inc.
 */

(function (window) {

    var WORKER_PATH = 'js/recorderWorker.js';

    var Recorder = function (source, cfg) {
        var config = cfg || {};
        var bufferLen = config.bufferLen || 4096;
        this.context = source.context;
        this.node = this.context.createScriptProcessor(bufferLen, 1, 1);
        console.log('this.context.sampleRate:' + this.context.sampleRate);
        var worker = new Worker(config.workerPath || WORKER_PATH);
        worker.postMessage({
            command: 'init',
            config: {
                sampleRate: this.context.sampleRate
            }
        });
        var recording = false,
            currCallback;

        this.node.onaudioprocess = function (e) {
            if (!recording) return;
            worker.postMessage({
                command: 'record',
                buffer: e.inputBuffer.getChannelData(0)
            });
        };

        this.record = function (cb) {
            currCallback = cb;
            recording = true;
        };

        this.stop = function () {
            recording = false;
        };

        worker.onmessage = function (e) {
            currCallback(e.data);
        };

        source.connect(this.node);
        this.node.connect(this.context.destination);    //this should not be necessary
    };
    window.Recorder = Recorder;
})(window);